from django.apps import AppConfig


class AggConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'agg'
