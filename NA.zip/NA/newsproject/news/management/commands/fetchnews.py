import requests
from django.core.management.base import BaseCommand
from news.models import NewsArticle

API_KEY = 'your_newsapi_key_here'  # Replace with your actual NewsAPI key
BASE_URL = 'https://newsapi.org/v2/top-headlines'

CATEGORY_MAP = {
    'sports': 'sports',
    'business': 'business',
    'politics': 'general',  # NewsAPI doesn't have 'politics', use 'general'
    'health': 'health',
    'facts': 'science',     # Map 'facts' to 'science'
    'puzzles': 'entertainment'  # Map puzzles to entertainment
}

class Command(BaseCommand):
    help = 'Fetch latest news from NewsAPI.org and store in database'

    def handle(self, *args, **kwargs):
        for local_cat, api_cat in CATEGORY_MAP.items():
            print(f'Fetching category: {local_cat}')
            url = f"{BASE_URL}?country=in&category={api_cat}&apiKey={API_KEY}"
            response = requests.get(url)
            data = response.json()

            for article in data.get('articles', []):
                title = article.get('title')
                content = article.get('description') or 'No content'

                # Avoid duplicates
                if not NewsArticle.objects.filter(title=title).exists():
                    NewsArticle.objects.create(
                        title=title,
                        content=content,
                        category=local_cat
                    )

        self.stdout.write(self.style.SUCCESS('News fetch completed successfully!'))
