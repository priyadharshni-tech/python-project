'''from django.http import HttpResponse

def home(request):
    return HttpResponse("Welcome to News Aggregator!")
'''
from django.shortcuts import render
from .models import NewsArticle

def home(request):
    category = request.GET.get('category')
    
    if category:
        news_items = NewsArticle.objects.filter(category__iexact=category)
        selected_category = category
    else:
        news_items = NewsArticle.objects.all()
        selected_category = "All"

    return render(request, 'home.html', {
        'news_items': news_items,
        'selected_category': category or "ALL",
    })